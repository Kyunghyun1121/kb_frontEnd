const path = require('path');

const join = path.join('some', 'work', 'ex.txt');
console.log(join);
