const path = require('path');

console.log(`파일 확장자: ${path.extname(__filename)}`);
