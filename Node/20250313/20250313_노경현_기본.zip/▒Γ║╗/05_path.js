const path = require('path');

console.log(path.parse(__filename));
