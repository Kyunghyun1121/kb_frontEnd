const getTriangle = (base, height) => (base * height) / 2;

console.log('삼각형의 면적 : ' + getTriangle(5, 2));
