const { user1, user2 } = require('./09_users-1');
const hello = require('./07_hello');

hello(user1);
hello(user2);
