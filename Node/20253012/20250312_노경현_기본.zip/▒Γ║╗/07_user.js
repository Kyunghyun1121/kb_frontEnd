const user = '홍길동';
module.exports = user;
