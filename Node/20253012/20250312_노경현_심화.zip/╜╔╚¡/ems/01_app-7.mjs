import { goodbye as bye } from './goodbye-1.mjs';

bye('홍길동');
