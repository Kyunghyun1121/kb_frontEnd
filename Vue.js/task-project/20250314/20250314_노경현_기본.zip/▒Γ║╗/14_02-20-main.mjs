import { add } from './13_02-19.mjs';

console.log(add(4));
