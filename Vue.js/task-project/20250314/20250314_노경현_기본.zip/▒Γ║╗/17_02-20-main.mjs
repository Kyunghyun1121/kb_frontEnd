import getBase, { add } from './16_02-19-modules.mjs';

console.log(add(4));
console.log(getBase());
